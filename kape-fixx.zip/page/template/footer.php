<script src="../../assets/bower_components/jquery/dist/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="../../assets/bower_components/jquery-ui/jquery-ui.min.js"></script>


<!-- Bootstrap 3.3.7 -->
<script src="../../assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- datepicker -->
<script src="../../assets/bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>
<script src="../../assets/bower_components/datatables/js/datatables.min.js"></script>
<script type="text/javascript" src="../../assets/bower_components/datatables/js/dataTables.bootstrap.min.js"></script>


<script src="../../assets/dist/js/moment.js"></script>

<!-- AdminLTE App -->
<script src="../../assets/dist/js/adminlte.min.js"></script>

</body>
</html>
