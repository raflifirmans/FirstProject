<?php 
header("location:page/login/login.php");
 ?>